import { Component } from '@angular/core';

@Component({
  selector: 'app-moto',
  templateUrl: './moto.component.html',
  styleUrl: './moto.component.scss'
})
export class MotoComponent {

}
