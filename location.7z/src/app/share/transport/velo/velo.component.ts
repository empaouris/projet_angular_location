import { Component } from '@angular/core';

@Component({
  selector: 'app-velo',
  templateUrl: './velo.component.html',
  styleUrl: './velo.component.scss'
})
export class VeloComponent {

}
