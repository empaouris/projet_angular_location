import { Component } from '@angular/core';

@Component({
  selector: 'app-immeuble',
  templateUrl: './immeuble.component.html',
  styleUrl: './immeuble.component.scss'
})
export class ImmeubleComponent {

}
