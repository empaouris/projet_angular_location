export interface Car {
    id:number ;
    model:string[];
    marque:string
}
    